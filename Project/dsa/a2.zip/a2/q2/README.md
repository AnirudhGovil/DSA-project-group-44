For hash table of size 100000, and a dictionary input with 84095 words

when p = 32
	The total collisions that occur are 52899.
	Average collisons per element = 0.63

when p = 33
	The total collisions that occur are 27184.
	Average collisons per element = 0.32

(I have considered addition of 100 numbers with same key to an empty hash table to be 99 collisions)
