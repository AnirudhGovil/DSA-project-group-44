alpha	 SC     linear	quadratic

0.1	0.18	0.19	0.21
0.2	0.35	0.46	0.46
0.3	0.66	0.72	0.73
0.4	0.81	1.02	1.05
0.5	0.97	1.73	1.51
0.6	1.17	3.12	 -
0.7	1.41	5.43	 - 
0.8	1.60	12.41	 -
0.9	1.77	44.08	 -


Time taken to add 2000 elements by Separate Chaining = 8.9 ms
Time taken to add 2000 elements by Linear Probing = 5.4 ms
Time taken to add 2000 elements by Quadratic Probing(rehashing at alpha=0.5) = 5.0 ms
